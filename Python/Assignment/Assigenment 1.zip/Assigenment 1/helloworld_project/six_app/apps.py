from django.apps import AppConfig


class SixAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'six_app'
