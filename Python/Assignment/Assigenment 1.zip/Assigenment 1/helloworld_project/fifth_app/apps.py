from django.apps import AppConfig


class FifthAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fifth_app'
