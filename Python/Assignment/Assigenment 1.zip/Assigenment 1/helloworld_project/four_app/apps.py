from django.apps import AppConfig


class FourAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'four_app'
